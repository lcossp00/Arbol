import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Codificacion 
{
	public Codificacion()
	{
		
	}

	private static class ObjetoCode
	{
		String simbolo;
		int pos;
		String code;
		
		ObjetoCode(String simbolo,int pos,String code)
		{
			this.simbolo = simbolo;
			this.pos = pos;
			this.code = code;
		}
		
		public String getCode()
		{
			return code;
		}
		
		public String getSimbolo()
		{
			return simbolo;
		}
		public int getPos()
		{
			return pos;
		}
    }
	
	public static void binario()
	{
		String cadena="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ .,;�?�!";
		char[] charCadena = cadena.toCharArray();
		ArrayList<String> myList = new ArrayList<String>();
		
		for(int i= 0; i < charCadena.length;i++)
		{
			myList.add("" + charCadena[i]);
		}
		
		ArrayList<ObjetoCode> listaObjetos = new ArrayList<ObjetoCode>();
		int cont = 0;
	
		for(String i : myList)
		{
			
			listaObjetos.add(new ObjetoCode(myList.get(cont),cont,obtenerBinario(cont)));
			/*System.out.print(listaObjetos.get(cont).getSimbolo()+" ");
			System.out.print(listaObjetos.get(cont).getCode()+" ");
			System.out.println(listaObjetos.get(cont).getPos());*/
			cont++;
		}
		
		
	}	
	
	public static String obtenerBinario(int numero)
	{
		   String binarioString = Integer.toBinaryString(numero); 
		   binarioString = rellenarBinario(binarioString);
		   return binarioString;
	}
	
	public static String rellenarBinario(String binario)
	{
		StringBuffer sb = new StringBuffer(6);
		int numero = binario.length();
		int cont = 6 - numero;

		for (int i=0 ; i < cont ; i++)
		{
		  sb.append("0");
		}
		
		sb.append(binario);
		
		binario = sb.toString();
		return binario;
	}

	public static String matriz() 
	{
		String code = "abcdefghijklmnopqrstuvwxyzrod"; /*"1,0,0,1,1,0,0,1,0,0,1,1,0,0,0,1,0,0,1,1,0,0,1,1,0,0,1," + 
				"1,0,0,1,1,1,1,0,0,1,0,0,1,1,0,0,0,0,0,0,0,0,0,1,0,0,1,1,"+
				"0,1,0,0,0,1,1,1,0,0,0,1,0,1,1,0,0,0,0,0,0,0,1,1,0,1,0,1,"+
				"0,1,1,0,1,0,1,0,0,1,1,1,0,0,0,0,1,0,0,1,1,0,1,0,0,1,1,0,"+
				"0,0,1,0,0,1,1,0,1,1,1,0,1,0,0,1,1,0,1,0,1,0,0,0,0,0,0,0,"+
				"0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,"+
				"1,0,0,0,1,0,1,1,0,0,0,0,0,0,0,1,0,0,0,1,1,1,0,1,0,0,1,1," + 
				"0,1,0,1,1,0,0,1,0,1,0,0,1,1,0,0,0,0,0,0,0,0,1,0,0,0,1,1," + 
				"1,1,1,1,0,1,0,0,0,0,1,1,1,1,0,0,1,0,1,1,0,1,0,0,1,0,1,0," + 
				"1,0,0,0,1,0,1,1,0,0,0,0,0,0,0,0,1,1,0,0,1,1,0,1,0,1,1,0," + 
				"1,0,0,0,0,0,0,0,1,0,0,0,1,1,1,0,0,0,0,0,0,0,1,1,0,0,0,0," + 
				"1,1,1,1,0,1,0,0,1,1,1,0,1,0,0,1,1,1,1,1,1,1,1,0,1,1,0,0,1";*/
		
		char[] cadenaSepara = code.toCharArray();
		ArrayList<String> arraySeparado = new ArrayList<String>();
		int count = 0;
		ArrayList<String> arraySiete = new ArrayList<String>(); 
		String siete = "";
		
		//Esto esta mal
		for(int i = 0;i<cadenaSepara.length;i++)
		{
			if(cadenaSepara[i] != ',')
			{
				arraySeparado.add("" + cadenaSepara[i]);
				
			}
			
		}
		//Trocear en 7 partes
		for(int j = 0;j<arraySeparado.size();j++)
		{
			if(count < 7)
			{
				siete = siete + arraySeparado.get(j);
				count++;
			}
			else
			{
				arraySiete.add(siete);
				count = 1;
				siete = "";
				siete = arraySeparado.get(j);
				
			}
			if(j == cadenaSepara.length - 1)
			{
				arraySiete.add(siete);
			}
			
		}
		System.out.println(arraySiete);
		return code;
	}
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		binario();
		matriz();
	}

}
